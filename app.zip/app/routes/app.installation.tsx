// ─────────────────────────────────────────────────────────────────────────────
// app.installation.tsx — Setup & Installation Guide
// Same palette: #1A73E8 blue, #0F172A dark, #22C55E green, #F8FAFC bg
// ─────────────────────────────────────────────────────────────────────────────

import { useNavigate } from "@remix-run/react";
import { useState } from "react";

const STEPS = [
  {
    id: 1,
    title: "Install the app",
    tag: "Already done",
    tagColor: "#22C55E",
    tagBg: "#F0FDF4",
    tagBorder: "#BBF7D0",
    accent: "#22C55E",
    bg: "#F0FDF4",
    border: "#BBF7D0",
    icon: (
      <svg width="22" height="22" fill="none" viewBox="0 0 24 24">
        <path d="M5 12l5 5L19 7" stroke="#22C55E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    content: (
      <div>
        <p style={{ fontSize: 14, color: "#64748B", lineHeight: 1.7, margin: "0 0 16px" }}>
          You've already completed this step — the app is installed and authenticated with your Shopify store.
        </p>
        <div style={{ background: "#F0FDF4", border: "1px solid #BBF7D0", borderRadius: 10, padding: "14px 16px", display: "flex", gap: 10, alignItems: "flex-start" }}>
          <svg width="16" height="16" fill="none" viewBox="0 0 24 24" style={{ flexShrink: 0, marginTop: 1 }}><path d="M5 12l5 5L19 7" stroke="#22C55E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
          <p style={{ margin: 0, fontSize: 13, color: "#166534", lineHeight: 1.6 }}>App is connected and ready. Your store credentials are securely stored.</p>
        </div>
      </div>
    ),
  },
  {
    id: 2,
    title: "Upload your first catalog",
    tag: "Step 2",
    tagColor: "#1A73E8",
    tagBg: "#EFF6FF",
    tagBorder: "#BFDBFE",
    accent: "#1A73E8",
    bg: "#EFF6FF",
    border: "#BFDBFE",
    icon: (
      <svg width="22" height="22" fill="none" viewBox="0 0 24 24">
        <path d="M12 15V4M12 4l-4 4M12 4l4 4" stroke="#1A73E8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1" stroke="#1A73E8" strokeWidth="2" strokeLinecap="round" />
      </svg>
    ),
    content: (
      <div>
        <p style={{ fontSize: 14, color: "#64748B", lineHeight: 1.7, margin: "0 0 20px" }}>
          Navigate to <strong style={{ color: "#0F172A" }}>Catalog listing</strong> in the sidebar and upload a PDF. Any product lookbook, brochure, or seasonal catalog works.
        </p>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {[
            { step: "1", text: "Go to Catalog listing → click Upload PDF" },
            { step: "2", text: "Drag and drop your PDF file (up to 50 MB)" },
            { step: "3", text: "Give your catalog a name and confirm the upload" },
            { step: "4", text: "Wait for processing — page extraction takes about 30 seconds" },
          ].map((s) => (
            <div key={s.step} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
              <div style={{ width: 24, height: 24, borderRadius: "50%", background: "#1A73E8", color: "#fff", fontSize: 11, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{s.step}</div>
              <p style={{ margin: 0, fontSize: 13, color: "#475569", lineHeight: 1.6, paddingTop: 3 }}>{s.text}</p>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 20, background: "#FFF7ED", border: "1px solid #FDE68A", borderRadius: 10, padding: "14px 16px" }}>
          <p style={{ margin: 0, fontSize: 13, color: "#92400E", lineHeight: 1.6 }}>
            <strong>Tip:</strong> Use high-resolution PDFs for the best page-flip experience. Images are extracted at full quality.
          </p>
        </div>
      </div>
    ),
  },
  {
    id: 3,
    title: "Add hotspot product pins",
    tag: "Step 3",
    tagColor: "#1A73E8",
    tagBg: "#EFF6FF",
    tagBorder: "#BFDBFE",
    accent: "#1A73E8",
    bg: "#EFF6FF",
    border: "#BFDBFE",
    icon: (
      <svg width="22" height="22" fill="none" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="3" stroke="#1A73E8" strokeWidth="2" />
        <circle cx="12" cy="12" r="8" stroke="#1A73E8" strokeWidth="2" strokeDasharray="3 3" />
      </svg>
    ),
    content: (
      <div>
        <p style={{ fontSize: 14, color: "#64748B", lineHeight: 1.7, margin: "0 0 20px" }}>
          Open any catalog from the listing to enter the editor. Click anywhere on a catalog page to place a hotspot pin and link it to a product.
        </p>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {[
            { step: "1", text: "Open a catalog → click any catalog page image" },
            { step: "2", text: "A pin editor panel appears on the right" },
            { step: "3", text: "Search for a product by name or SKU from your Shopify store" },
            { step: "4", text: "Select the product — the pin is saved automatically" },
            { step: "5", text: "Repeat for as many products as you like across all pages" },
          ].map((s) => (
            <div key={s.step} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
              <div style={{ width: 24, height: 24, borderRadius: "50%", background: "#1A73E8", color: "#fff", fontSize: 11, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{s.step}</div>
              <p style={{ margin: 0, fontSize: 13, color: "#475569", lineHeight: 1.6, paddingTop: 3 }}>{s.text}</p>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 20, background: "#FFF7ED", border: "1px solid #FDE68A", borderRadius: 10, padding: "14px 16px" }}>
          <p style={{ margin: 0, fontSize: 13, color: "#92400E", lineHeight: 1.6 }}>
            <strong>Tip:</strong> Drag existing pins to reposition them. You can delete a pin by double clicking it and pressing the trash icon.
          </p>
        </div>
      </div>
    ),
  },
  {
    id: 4,
    title: "Customise hotspot appearance",
    tag: "Optional",
    tagColor: "#94A3B8",
    tagBg: "#F1F5F9",
    tagBorder: "#E2E8F0",
    accent: "#F59E0B",
    bg: "#FFFBEB",
    border: "#FDE68A",
    icon: (
      <svg width="22" height="22" fill="none" viewBox="0 0 24 24">
        <path d="M12 15a3 3 0 100-6 3 3 0 000 6z" stroke="#F59E0B" strokeWidth="2" />
        <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" stroke="#F59E0B" strokeWidth="2" />
      </svg>
    ),
    content: (
      <div>
        <p style={{ fontSize: 14, color: "#64748B", lineHeight: 1.7, margin: "0 0 20px" }}>
          Go to <strong style={{ color: "#0F172A" }}>Global settings</strong> to control how pins and tooltips look across all your catalogs.
        </p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          {[
            { label: "Pin color", desc: "Match your brand palette" },
            { label: "Tooltip style", desc: "Dark, light, or custom" },
            { label: "Button design", desc: "Text, size, corner radius" },
            { label: "Animation type", desc: "Bounce, pulse, or static" },
          ].map((item) => (
            <div key={item.label} style={{ background: "#fff", border: "1px solid #E8EDF2", borderRadius: 9, padding: "12px 14px" }}>
              <p style={{ margin: "0 0 3px", fontSize: 13, fontWeight: 600, color: "#0F172A" }}>{item.label}</p>
              <p style={{ margin: 0, fontSize: 12, color: "#94A3B8" }}>{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 5,
    title: "Embed the catalog in your theme",
    tag: "Step 4",
    tagColor: "#1A73E8",
    tagBg: "#EFF6FF",
    tagBorder: "#BFDBFE",
    accent: "#1A73E8",
    bg: "#EFF6FF",
    border: "#BFDBFE",
    icon: (
      <svg width="22" height="22" fill="none" viewBox="0 0 24 24">
        <path d="M16 18l6-6-6-6M8 6l-6 6 6 6" stroke="#1A73E8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    content: (
      <div>
        <p style={{ fontSize: 14, color: "#64748B", lineHeight: 1.7, margin: "0 0 20px" }}>
          Each catalog has a unique key. Use it to embed a page-flip viewer anywhere in your Shopify storefront.
        </p>

        <p style={{ fontSize: 13, fontWeight: 600, color: "#0F172A", margin: "0 0 10px" }}>Option A — Theme block (recommended)</p>
        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 22 }}>
          {[
            { step: "1", text: "Go to your catalog in Catalog listing → copy the Catalog Key" },
            { step: "2", text: "In Shopify Admin, go to Online Store → Themes → Customize" },
            { step: "3", text: 'Add a new section or block — search for "PDF Catalog Viewer"' },
            { step: "4", text: "Paste your Catalog Key into the block settings and save" },
          ].map((s) => (
            <div key={s.step} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
              <div style={{ width: 24, height: 24, borderRadius: "50%", background: "#1A73E8", color: "#fff", fontSize: 11, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{s.step}</div>
              <p style={{ margin: 0, fontSize: 13, color: "#475569", lineHeight: 1.6, paddingTop: 3 }}>{s.text}</p>
            </div>
          ))}
        </div>

        <p style={{ fontSize: 13, fontWeight: 600, color: "#0F172A", margin: "0 0 10px" }}>Option B — Embed via Liquid snippet</p>
        <div style={{ background: "#0F172A", borderRadius: 10, padding: "14px 16px", marginBottom: 16 }}>
          <code style={{ fontSize: 12, color: "#94A3B8", fontFamily: "'Fira Code', 'Cascadia Code', monospace", lineHeight: 1.8 }}>
            {"{% render 'pdf-catalog', catalog_key: 'YOUR_CATALOG_KEY' %}"}
          </code>
        </div>
        <div style={{ background: "#FFF7ED", border: "1px solid #FDE68A", borderRadius: 10, padding: "14px 16px" }}>
          <p style={{ margin: 0, fontSize: 13, color: "#92400E", lineHeight: 1.6 }}>
            <strong>Note:</strong> The Liquid snippet requires the app's theme extension to be enabled. Enable it from Online Store → Themes → Extensions.
          </p>
        </div>
      </div>
    ),
  },
  {
    id: 6,
    title: "Go live & verify",
    tag: "Final step",
    tagColor: "#22C55E",
    tagBg: "#F0FDF4",
    tagBorder: "#BBF7D0",
    accent: "#22C55E",
    bg: "#F0FDF4",
    border: "#BBF7D0",
    icon: (
      <svg width="22" height="22" fill="none" viewBox="0 0 24 24">
        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" stroke="#22C55E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    content: (
      <div>
        <p style={{ fontSize: 14, color: "#64748B", lineHeight: 1.7, margin: "0 0 20px" }}>
          Preview your storefront to confirm everything looks great before announcing to customers.
        </p>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {[
            { icon: "🖥", text: "Open your store's live URL and navigate to the page with the catalog" },
            { icon: "📖", text: "Confirm the page-flip viewer loads and pages turn smoothly" },
            { icon: "📍", text: "Click a hotspot pin — the product tooltip should appear with price and Add to Cart" },
            { icon: "🛒", text: "Test adding a product to cart from the tooltip" },
            { icon: "📱", text: "Check the experience on mobile — the viewer is fully responsive" },
          ].map((item, i) => (
            <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start", background: "#fff", border: "1px solid #E8EDF2", borderRadius: 9, padding: "12px 14px" }}>
              <span style={{ fontSize: 16, flexShrink: 0 }}>{item.icon}</span>
              <p style={{ margin: 0, fontSize: 13, color: "#475569", lineHeight: 1.6 }}>{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    ),
  },
];

const FAQ = [
  {
    q: "How many catalogs can I upload?",
    a: "The Free plan supports 1 catalog. Upgrade to Basic (5 catalogs) or Advanced (unlimited) for more. You can manage your plan under Plans in the sidebar.",
  },
  {
    q: "What PDF file size is supported?",
    a: "Up to 50 MB per upload on all plans. For best performance, compress your PDF before uploading if it exceeds 20 MB.",
  },
  {
    q: "Will the catalog show on mobile devices?",
    a: "Yes — the page-flip viewer is fully responsive and works on phones and tablets. On small screens, pages display single-page instead of spread.",
  },
  {
    q: "Can I update a catalog after publishing?",
    a: "Yes. Open the catalog from Catalog listing, edit hotspot pins, and changes are reflected live immediately. To replace the PDF, delete the catalog and re-upload.",
  },
  {
    q: "What happens when a linked product is deleted from Shopify?",
    a: "The hotspot pin remains visible but the product tooltip will show a 'product unavailable' message. We recommend reviewing pins when you remove products.",
  },
];

const Installation = () => {
  const navigate = useNavigate();
  const [openStep, setOpenStep] = useState<number | null>(1);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div style={{ minHeight: "100vh", backgroundColor: "#F8FAFC", fontFamily: "'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" }}>
      <style>{`
        @keyframes fadeUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
        .heroBtn:hover { background: #1557b0 !important; }
        .accordionRow:hover { background: #F8FAFC !important; }
        .faqRow:hover { background: #F8FAFC !important; }
      `}</style>

      {/* ── HEADER ── */}
      <div style={{ background: "#fff", borderBottom: "1px solid #E8EDF2", padding: "40px 48px" }}>
        <div style={{ maxWidth: 860, margin: "0 auto" }}>
          <button onClick={() => navigate("/app")}
            style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "none", border: "none", cursor: "pointer", color: "#64748B", fontSize: 13, padding: 0, marginBottom: 20 }}>
            <svg width="14" height="14" fill="none" viewBox="0 0 24 24"><path d="M19 12H5M5 12l7-7M5 12l7 7" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" /></svg>
            Back to Home
          </button>

          <div style={{ display: "block", width:"100px", background: "#EFF6FF", border: "1px solid #BFDBFE", borderRadius: 99, padding: "4px 12px", marginBottom: 18 }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#1A73E8", display: "inline-block" }} />
            <span style={{ fontSize: 11, color: "#1A73E8", fontWeight: 500, letterSpacing: "0.02em" }}>Setup Guide</span>
          </div>

          <h1 style={{ fontSize: 32, fontWeight: 700, color: "#0F172A", lineHeight: 1.2, margin: "0 0 12px", letterSpacing: "-0.03em" }}>
            Get your catalog live in{" "}
            <span style={{ color: "#1A73E8" }}>four steps</span>
          </h1>
          <p style={{ fontSize: 15, color: "#64748B", lineHeight: 1.7, maxWidth: 560, margin: 0 }}>
            Follow this guide to upload a catalog, tag your products with hotspot pins, and embed the viewer in your Shopify storefront.
          </p>

          {/* Progress indicators */}
          <div style={{ display: "flex", gap: 8, marginTop: 28, flexWrap: "wrap" }}>
            {["Install app", "Upload catalog", "Tag products", "Embed viewer", "Go live"].map((label, i) => (
              <div key={label} style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <div style={{ display: "inline-flex", alignItems: "center", gap: 6, background: i === 0 ? "#F0FDF4" : "#EFF6FF", border: `1px solid ${i === 0 ? "#BBF7D0" : "#BFDBFE"}`, borderRadius: 99, padding: "4px 10px" }}>
                  {i === 0 && <svg width="10" height="10" fill="none" viewBox="0 0 24 24"><path d="M5 12l5 5L19 7" stroke="#22C55E" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>}
                  <span style={{ fontSize: 11, color: i === 0 ? "#166534" : "#1A73E8", fontWeight: 500 }}>{label}</span>
                </div>
                {i < 4 && <svg width="12" height="12" fill="none" viewBox="0 0 24 24"><path d="M9 6l6 6-6 6" stroke="#CBD5E1" strokeWidth="2" strokeLinecap="round" /></svg>}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── MAIN CONTENT ── */}
      <div style={{ maxWidth: 860, margin: "0 auto", padding: "40px 48px 0" }}>

        {/* Steps accordion */}
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {STEPS.map((step) => {
            const isOpen = openStep === step.id;
            return (
              <div key={step.id}
                style={{ background: "#fff", border: `1px solid ${isOpen ? step.border : "#E8EDF2"}`, borderRadius: 14, overflow: "hidden", transition: "border-color 0.2s", boxShadow: isOpen ? `0 4px 20px rgba(15,23,42,0.06)` : "none" }}>
                <button className="accordionRow"
                  onClick={() => setOpenStep(isOpen ? null : step.id)}
                  style={{ width: "100%", display: "flex", alignItems: "center", gap: 16, padding: "18px 22px", background: "none", border: "none", cursor: "pointer", textAlign: "left", transition: "background 0.15s" }}>
                  <div style={{ width: 42, height: 42, borderRadius: 11, background: isOpen ? step.bg : "#F8FAFC", border: `1px solid ${isOpen ? step.border : "#E8EDF2"}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "background 0.2s, border-color 0.2s" }}>
                    {step.icon}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 3 }}>
                      <span style={{ fontSize: 14, fontWeight: 600, color: "#0F172A" }}>{step.title}</span>
                      <span style={{ fontSize: 11, fontWeight: 500, color: step.tagColor, background: step.tagBg, border: `1px solid ${step.tagBorder}`, borderRadius: 99, padding: "2px 8px" }}>{step.tag}</span>
                    </div>
                  </div>
                  <svg width="16" height="16" fill="none" viewBox="0 0 24 24"
                    style={{ transform: isOpen ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s", color: "#94A3B8", flexShrink: 0 }}>
                    <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
                {isOpen && (
                  <div style={{ padding: "0 22px 22px 80px", animation: "fadeUp 0.2s ease both" }}>
                    {step.content}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* ── NEED HELP BANNER ── */}
        <div style={{ marginTop: 28, background: "#fff", border: "1px solid #E8EDF2", borderRadius: 14, padding: "28px 32px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 20, flexWrap: "wrap" }}>
          <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
            <div style={{ width: 44, height: 44, borderRadius: 11, background: "#EFF6FF", border: "1px solid #BFDBFE", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <svg width="20" height="20" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="#1A73E8" strokeWidth="1.75" /><path d="M12 8v4M12 16h.01" stroke="#1A73E8" strokeWidth="1.75" strokeLinecap="round" /></svg>
            </div>
            <div>
              <p style={{ margin: "0 0 2px", fontSize: 14, fontWeight: 600, color: "#0F172A" }}>Need help?</p>
              <p style={{ margin: 0, fontSize: 13, color: "#64748B" }}>Check the FAQ below or reach out to our support team.</p>
            </div>
          </div>
          <a href="mailto:support@example.com"
            style={{ display: "inline-flex", alignItems: "center", gap: 7, background: "#F8FAFC", color: "#374151", border: "1px solid #D1D5DB", borderRadius: 9, padding: "10px 18px", fontSize: 13, fontWeight: 500, cursor: "pointer", textDecoration: "none", whiteSpace: "nowrap" }}>
            <svg width="14" height="14" fill="none" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" stroke="currentColor" strokeWidth="1.75" strokeLinejoin="round" /><path d="M22 6l-10 7L2 6" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" /></svg>
            Contact support
          </a>
        </div>

        {/* ── FAQ ── */}
        <div style={{ marginTop: 44 }}>
          <span style={{ fontSize: 11, fontWeight: 600, color: "#1A73E8", letterSpacing: "0.1em", textTransform: "uppercase" }}>FAQ</span>
          <h2 style={{ fontSize: 22, fontWeight: 700, color: "#0F172A", margin: "6px 0 20px", letterSpacing: "-0.02em" }}>Frequently asked questions</h2>

          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {FAQ.map((item, i) => {
              const isOpen = openFaq === i;
              return (
                <div key={i} style={{ background: "#fff", border: "1px solid #E8EDF2", borderRadius: 12, overflow: "hidden" }}>
                  <button className="faqRow"
                    onClick={() => setOpenFaq(isOpen ? null : i)}
                    style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16, padding: "16px 20px", background: "none", border: "none", cursor: "pointer", textAlign: "left", transition: "background 0.15s" }}>
                    <span style={{ fontSize: 14, fontWeight: 500, color: "#0F172A" }}>{item.q}</span>
                    <svg width="16" height="16" fill="none" viewBox="0 0 24 24"
                      style={{ transform: isOpen ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s", color: "#94A3B8", flexShrink: 0 }}>
                      <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </button>
                  {isOpen && (
                    <div style={{ padding: "0 20px 18px", animation: "fadeUp 0.15s ease both" }}>
                      <p style={{ margin: 0, fontSize: 13, color: "#64748B", lineHeight: 1.7 }}>{item.a}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* ── BOTTOM CTA ── */}
        <div style={{ margin: "40px 0 60px", background: "linear-gradient(135deg, #EFF6FF 0%, #F0FDF4 100%)", border: "1px solid #BFDBFE", borderRadius: 14, padding: "32px 36px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 20, flexWrap: "wrap" }}>
          <div>
            <h3 style={{ fontSize: 18, fontWeight: 700, color: "#0F172A", margin: "0 0 4px", letterSpacing: "-0.02em" }}>Ready to upload your first catalog?</h3>
            <p style={{ fontSize: 13, color: "#64748B", margin: 0 }}>Go live in under five minutes. No code required.</p>
          </div>
          <button className="heroBtn" onClick={() => navigate("/app/pdf-convert")}
            style={{ display: "inline-flex", alignItems: "center", gap: 7, background: "#1A73E8", color: "#fff", border: "none", borderRadius: 9, padding: "12px 22px", fontSize: 14, fontWeight: 500, cursor: "pointer", boxShadow: "0 2px 8px rgba(26,115,232,0.3)", transition: "background 0.15s", letterSpacing: "-0.01em", whiteSpace: "nowrap" }}>
            <svg width="15" height="15" fill="none" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" stroke="white" strokeWidth="2.5" strokeLinecap="round" /></svg>
            Upload a catalog
          </button>
        </div>
      </div>
    </div>
  );
};

export default Installation;
